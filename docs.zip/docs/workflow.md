# Team Workflow
The assignment PDF is the source of truth for requirements. This file only covers how we work.
## Ownership
See Work Division in `README.md`. Each member commits their own part from their own GitHub account.
## Branches
```
dev/<name>  ->  commit  ->  push  ->  Pull Request  ->  merge to main
```
Do not commit directly to `main`.
## Commit Messages
```
type(scope): message
```
Types: `feat`, `fix`, `refactor`, `docs`, `chore`. Example: `feat(board): add placement check`.
## Shared Code
- Arham owns the methods in `docs/method-list.md` and `data/best_score.txt`. Tell Arham before changing either.
- Arham handles bugs that cross modules.
## Schedule
 Date  Target 
 Nov 3 | Structure and method list on `main` 
 Nov 4 | Window draws a live board, `BlockPiece` and `Board` done, drag-and-place calls `Game`.
 Nov 5 | Playable end to end, merged to `main` ,
 Nov 6 | Screens, sound and effects done, checked line by line against the PDF.
 Nov 7 | Fixes, README finished, code freeze, practise explaining your part .
 Nov 8 | Deadline, buffer only,
Commits after the deadline do not count.
