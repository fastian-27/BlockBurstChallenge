# Shared Method List
Agreed method names between `blocked.model` and `blocked.ui`.  
```java
// BlockPiece
int getRows();
int getCols();
boolean isFilled(int row, int col);
Color getColor();
// Board
static final int SIZE = 8;
boolean canPlace(BlockPiece piece, int row, int col);
void place(BlockPiece piece, int row, int col);
boolean canFitAnywhere(BlockPiece piece);
Color getCell(int row, int col);     // null means empty
ClearResult clearCompletedLines();   // cleared rows, cleared columns, cell count
// Game
void start(GameMode mode);
void tick(int deltaMs);              // called by the Timer, does nothing unless PLAYING
boolean canPlace(int slot, int row, int col);       // for the preview
PlaceResult tryPlace(int slot, int row, int col);   // valid?, points, ClearResult
void pause();
void resume();
void restart();
void returnToMenu();
GameState getState();
GameMode getMode();
Board getBoard();
BlockPiece getTrayPiece(int slot);   // null means already used
int getScore();
int getBestScore();
int getElapsedSeconds();
int getRemainingSeconds();           // Time Attack
```
Mute is not listed here because it belongs to `SoundManager` in `blocked.ui`.
