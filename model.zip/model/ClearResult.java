package blocked.model;

public class ClearResult {
    private final int[] rows;
    private final int[] cols;
    private final int cellCount;

    public ClearResult(int[] rows, int[] cols, int cellCount) {
        this.rows = rows.clone();
        this.cols = cols.clone();
        this.cellCount = cellCount;
    }

    public int[] getRows() {
        return rows.clone();
    }

    public int[] getCols() {
        return cols.clone();
    }

    public int getCellCount() {
        return cellCount;
    }
}
