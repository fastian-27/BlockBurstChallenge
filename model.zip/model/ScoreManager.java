package blocked.model;

public class ScoreManager {
    
}
