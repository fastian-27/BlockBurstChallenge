package blocked.model;

import java.awt.Color;

public class BlockPiece {
    private final boolean[][] shape;
    private final Color color;

    public BlockPiece(boolean[][] shape, Color color) {
        // 1. Reject bad input
        if (shape == null) {
            throw new IllegalArgumentException("Shape cannot be null");
        }
        if (shape.length == 0) {
            throw new IllegalArgumentException("Shape cannot be empty");
        }
        if (shape[0].length == 0) {
            throw new IllegalArgumentException("Shape's first row cannot be empty");
        }
        for (int r = 0; r < shape.length; r++) {
            if (shape[r].length != shape[0].length) {
                throw new IllegalArgumentException("Shape cannot have inconsistent row length");
            }
        }
        if (color == null) {
            throw new IllegalArgumentException("Color cannot be null");
        }
        // 2. Store the shape
        boolean[][] copy = new boolean[shape.length][];
        for (int r = 0; r < shape.length; r++) {
            copy[r] = shape[r].clone();
        }
        this.shape = copy;
        // 3. Store the color
        this.color = color;
    }

    public int getRows() {
        return shape.length;
    }

    public int getCols() {
        return shape[0].length;
    }

    public boolean isFilled(int row, int col) {
        return shape[row][col];
    }

    public Color getColor() {
        return color;
    }

    public int getCellCount() {
        int count = 0;
        for (int row = 0; row < getRows(); row++) {
            for (int col = 0; col < getCols(); col++) {
                if (isFilled(row, col)) count++;
            }
        }
        return count;
    }
}
