package blocked.model;

import java.util.Arrays;
import java.awt.Color;

public class Board {
    public static final int SIZE = 8;

    private final Color[][] cells = new Color[SIZE][SIZE];

    public boolean canPlace(BlockPiece piece, int row, int col) {
        for (int r = 0; r < piece.getRows(); r++) {
            for (int c = 0; c < piece.getCols(); c++) {
                if (!piece.isFilled(r, c)) continue;
                int boardRow = row + r, boardCol = col + c;
                if (boardRow < 0 || boardRow >= SIZE || boardCol < 0 || boardCol >= SIZE) {
                    return false;
                }
                if (cells[boardRow][boardCol] != null) {
                    return false;
                }
            }
        }
        return true;
    }

    public Color getCell(int row, int col) {
        return cells[row][col];
    }

    public void place(BlockPiece piece, int row, int col) {
        if (!canPlace(piece, row, col)) {
            throw new IllegalArgumentException("Cannot place piece here");
        }
        for (int r = 0; r < piece.getRows(); r++) {
            for (int c = 0; c < piece.getCols(); c++) {
                if (!piece.isFilled(r, c)) continue;
                cells[row + r][col + c] = piece.getColor();
            }
        }
    }

    public boolean canFitAnywhere(BlockPiece piece) {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (canPlace(piece, row, col)) return true;
            }
        }
        return false;
    }

    private boolean isRowFull(int row) {
        for (int c = 0; c < SIZE; c++) {
            if (cells[row][c] == null) return false;
        }
        return true;
    }

    private boolean isColFull(int col) {
        for (int r = 0; r < SIZE; r++) {
            if (cells[r][col] == null) return false;
        }
        return true;
    }

    public ClearResult clearCompletedLines() {
        int[] fullRows = new int[SIZE];
        int rowCount = 0;
        for (int row = 0; row < SIZE; row++) {
            if (isRowFull(row)) {
                fullRows[rowCount] = row;
                rowCount++;
            }
        }
        int[] fullCols = new int[SIZE];
        int colCount = 0;
        for (int col = 0; col < SIZE; col++) {
            if (isColFull(col)) {
                fullCols[colCount] = col;
                colCount++;
            }
        }

        int cleared = 0;
        for (int row = 0; row < rowCount; row++) {
            for (int c = 0; c < SIZE; c++) {
                if (cells[fullRows[row]][c] != null) {
                    cleared++;
                    cells[fullRows[row]][c] = null;
                }
            }
        }
        for (int col = 0; col < colCount; col++) {
            for (int r = 0; r < SIZE; r++) {
                if (cells[r][fullCols[col]] != null) {
                    cleared++;
                    cells[r][fullCols[col]] = null;
                }
            }
        }

        return new ClearResult(Arrays.copyOf(fullRows, rowCount), Arrays.copyOf(fullCols, colCount), cleared);
    }

    public void clear() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                cells[r][c] = null;
            }
        }
    }
}
