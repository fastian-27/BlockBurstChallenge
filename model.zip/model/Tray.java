package blocked.model;

public class Tray {
    
}
