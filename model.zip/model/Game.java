package blocked.model;

public class Game {
    private static final int POINTS_PER_CELL_PLACED = 1;
    private static final int POINTS_PER_CELL_CLEARED = 10;
    private static final int NUMBER_OF_SLOTS = 3;

    private final Board board = new Board();
    private final PieceGenerator generator = new PieceGenerator();
    private final BlockPiece[] tray = new BlockPiece[NUMBER_OF_SLOTS];
    private int score;
    private GameState state = GameState.PLAYING;

    public Game() {
        refillTray();
    }

    private boolean anyPieceFits() {
        for (int slot = 0; slot < NUMBER_OF_SLOTS; slot++) {
            BlockPiece piece = getTrayPiece(slot);
            if (piece == null) continue;
            if (board.canFitAnywhere(piece)) return true;
        }
        return false;
    }

    public void pause() {
        if (state == GameState.PLAYING) state = GameState.PAUSED;
    }

    public void resume() {
        if (state == GameState.PAUSED) state = GameState.PLAYING;
    }

    private void refillTray() {
        for (int i = 0; i < NUMBER_OF_SLOTS; i++) {
            tray[i] = generator.next();
        }
    }

    private boolean isTrayEmpty() {
        for (int i = 0; i < NUMBER_OF_SLOTS; i++) {
            if (tray[i] != null) return false;
        }
        return true;
    }

    public BlockPiece getTrayPiece(int slot) {
        if (slot < 0 || slot > NUMBER_OF_SLOTS - 1) return null;
        return tray[slot];
    }

    public boolean canPlace(int slot, int row, int col) {
        if (state != GameState.PLAYING) return false;
        BlockPiece piece = getTrayPiece(slot);
        if (piece == null) return false;
        return board.canPlace(piece, row, col);
    }

    public boolean placePiece(int slot, int row, int col) {
        if (!canPlace(slot, row, col)) return false;
        BlockPiece piece = getTrayPiece(slot);
        board.place(piece, row, col);
        ClearResult result = board.clearCompletedLines();
        score += piece.getCellCount() * POINTS_PER_CELL_PLACED;
        score += result.getCellCount() * POINTS_PER_CELL_CLEARED;
        tray[slot] = null;
        if (isTrayEmpty()) refillTray();
        if (!anyPieceFits()) state = GameState.GAME_OVER;
        return true;
    }

    public Board getBoard() {
        return board;
    }

    public int getScore() {
        return score;
    }

    public GameState getState() {
        return state;
    }

    public void reset() {
        board.clear();
        score = 0;
        refillTray();
        state = GameState.PLAYING;
    }
}
