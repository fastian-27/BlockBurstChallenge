package blocked.model;

import java.awt.Color;
import java.util.Random;

public class PieceGenerator {
    private static final boolean X = true, O = false;

    private static final boolean[][][] SHAPES = {
        { {X} },
        { {X, X} },
        { {X}, {X} },
        { {X, X, X} },
        { {X},{X}, {X} },
        { {X, X, X, X} },
        { {X}, {X}, {X}, {X} },
        { {X, X, X, X, X} },
        { {X}, {X}, {X}, {X}, {X} },
        { {X, X}, {X, X} },
        { {X, X, X}, {X, X, X} },
        { {X, X}, {X, X}, {X, X} },
        { {X, X}, {X, O}, {X, O} },
        { {X, X}, {O, X}, {O, X} },
        { {X, O}, {X, O}, {X, X} },
        { {O, X}, {O, X}, {X, X} },
        { {X, X, X}, {X, O, O} },
        { {X, X, X}, {O, O, X} },
        { {X, O, O}, {X, X, X} },
        { {O, O, X}, {X, X, X} },
        { {X, X, X}, {O, X, O} },
        { {O, X, O}, {X, X, X} },
        { {X, O}, {X, X}, {X, O} },
        { {O, X}, {X, X}, {O, X} },
        { {O, X, X}, {X, X, O} },
        { {X, X, O}, {O, X, X} },
        { {X, O}, {X, X}, {O, X} },
        { {O, X}, {X, X}, {X, O} }
    };

    private static final Color[] COLORS = {
        new Color(60, 130, 255),
        Color.RED,
        Color.GREEN,
        Color.CYAN,
        Color.MAGENTA,
        Color.YELLOW,
        Color.ORANGE,
        Color.PINK
    };

    private final Random random = new Random();

    public BlockPiece next() {
        return new BlockPiece(SHAPES[random.nextInt(SHAPES.length)], COLORS[random.nextInt(COLORS.length)]);
    }
}
