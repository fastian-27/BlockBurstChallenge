# Sound Files

This directory should contain the following WAV sound files:

1. **select.wav** - Played when a piece is selected
2. **place.wav** - Played when a piece is successfully placed
3. **clear.wav** - Played when rows/columns are cleared
4. **invalid.wav** - Played when an invalid placement is attempted
5. **gameover.wav** - Played when the game ends

## Getting Sound Files

You can:
1. Download free WAV files from the assignment's Google Drive link
2. Create your own using audio software
3. Find free sound effects from sites like:
   - freesound.org
   - zapsplat.com
   - mixkit.co

## Format Requirements

- **Format**: WAV (Waveform Audio File Format)
- **Channels**: Mono or Stereo
- **Sample Rate**: 44.1 kHz recommended
- **Bit Depth**: 16-bit recommended

## Notes

- The SoundManager handles missing files gracefully
- If a sound file is missing, a warning will be printed but the game will continue
- Keep sound files small (under 1 MB each) for quick loading
