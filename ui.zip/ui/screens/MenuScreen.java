package blocked.ui.screens;

import blocked.ui.Renderer;

public class MenuScreen implements Screen {

    @Override
    public void update() {
    }

    @Override
    public void draw(Renderer renderer) {
        renderer.drawText("BLOCKED.exe", 280, 250);
        renderer.drawText("Press Space or Enter to play", 275, 300);
    }
}
