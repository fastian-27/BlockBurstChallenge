package blocked.ui.screens;

import blocked.ui.Renderer;

public class PauseScreen implements Screen {

    @Override
    public void update() {
    }

    @Override
    public void draw(Renderer renderer) {
        renderer.drawText("GAME PAUSED", 315, 250);
        renderer.drawText("Press P to resume", 315, 300);
    }
}
