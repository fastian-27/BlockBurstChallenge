package blocked.ui.screens;

import blocked.ui.Renderer;

public interface Screen {

    void update();

    void draw(Renderer renderer);
}
