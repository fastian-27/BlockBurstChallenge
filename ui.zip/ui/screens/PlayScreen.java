package blocked.ui.screens;

import java.awt.Color;

import blocked.ui.Renderer;

public class PlayScreen implements Screen {

    private static final int WIDTH = 800;
    private static final int SHAPE_SIZE = 50;

    private int shapeX;
    private int shapeDirection = 1;

    @Override
    public void update() {
        shapeX += shapeDirection * 2;

        if (shapeX <= 0 || shapeX >= WIDTH - SHAPE_SIZE) {
            shapeDirection *= -1;
            shapeX = Math.max(0, Math.min(shapeX, WIDTH - SHAPE_SIZE));
        }
    }

    @Override
    public void draw(Renderer renderer) {
        renderer.drawBlock(shapeX, 275, Color.RED);
        renderer.drawText("Press Space or Enter for menu", 20, 30);
    }
}
