package blocked.ui;

import javax.swing.JFrame;

public class GameFrame extends JFrame {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;

    public GameFrame() {
        super("BLOCKED.exe");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        add(new GamePanel());
        setLocationRelativeTo(null);
    }
}
