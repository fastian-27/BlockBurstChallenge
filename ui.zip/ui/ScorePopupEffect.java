package blocked.ui;

import java.awt.*;

/**
 * Visual effect that shows a score value floating upward and fading.
 * Displayed when points are earned from placing pieces or clearing lines.
 * 
 * @author Saim Arif Khan
 */
public class ScorePopupEffect extends Effect {
    
    private String scoreText;
    private Font font;
    private Color textColor;
    private int floatDistance;
    
    /**
     * Creates a score popup effect.
     * 
     * @param x X position
     * @param y Starting Y position
     * @param score The score value to display
     * @throws IllegalArgumentException if score is negative
     */
    public ScorePopupEffect(int x, int y, int score) {
        super(x, y, 1000);  // 1 second duration
        
        if (score < 0) {
            throw new IllegalArgumentException("Score must be non-negative, got: " + score);
        }
        
        this.scoreText = "+" + score;
        this.font = new Font("Arial", Font.BOLD, 24);
        this.textColor = new Color(255, 215, 0);  // Gold color
        this.floatDistance = 50;  // Float up 50 pixels
    }
    
    @Override
    public void draw(Graphics2D g2d) {
        if (g2d == null) {
            System.err.println("Error: Graphics2D context is null");
            return;
        }
        
        if (scoreText == null || font == null) {
            System.err.println("Error: Invalid state in ScorePopupEffect");
            return;
        }
        
        try {
            float progress = getProgress();
        
            // Float upward
            int currentY = y - (int) (floatDistance * progress);
            
            // Fade out
            float alpha = 1.0f - progress;
            
            // Scale up slightly at the beginning, then shrink
            float scale = 1.0f;
            if (progress < 0.2f) {
                scale = 0.5f + (progress / 0.2f) * 0.7f;  // 0.5 to 1.2
            } else if (progress > 0.8f) {
                scale = 1.2f - ((progress - 0.8f) / 0.2f) * 0.4f;  // 1.2 to 0.8
            } else {
                scale = 1.2f;
            }
            
            Color currentColor = new Color(
                textColor.getRed(),
                textColor.getGreen(),
                textColor.getBlue(),
                (int) (alpha * 255)
            );
            
            g2d.setColor(currentColor);
            
            // Apply scaled font
            Font scaledFont = font.deriveFont(font.getSize() * scale);
            g2d.setFont(scaledFont);
            
            // Draw text centered
            FontMetrics metrics = g2d.getFontMetrics();
            int textWidth = metrics.stringWidth(scoreText);
            int textHeight = metrics.getHeight();
            
            // Draw shadow for better visibility
            Color shadowColor = new Color(0, 0, 0, (int) (alpha * 128));
            g2d.setColor(shadowColor);
            g2d.drawString(scoreText, x - textWidth / 2 + 2, currentY + 2);
            
            // Draw actual text
            g2d.setColor(currentColor);
            g2d.drawString(scoreText, x - textWidth / 2, currentY);
            
        } catch (Exception e) {
            System.err.println("Error drawing ScorePopupEffect: " + e.getMessage());
        }
    }
}
