package blocked.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Simple test program to demonstrate Saim's effects and sound system.
 * Run this to verify all animations and sounds work independently.
 * 
 * @author Saim Arif Khan
 */
public class TestEffects extends JPanel {
    
    private List<Effect> activeEffects = new ArrayList<>();
    private SoundManager soundManager;
    
    public TestEffects() {
        soundManager = SoundManager.getInstance();
        setPreferredSize(new Dimension(800, 600));
        setBackground(new Color(30, 30, 40));
        
        // Mouse click adds effects
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                
                if (SwingUtilities.isLeftMouseButton(e)) {
                    // Add placement pop effect
                    activeEffects.add(new PlacementPopEffect(x, y, 50));
                    soundManager.playPiecePlaced();
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    // Add score popup
                    activeEffects.add(new ScorePopupEffect(x, y, 100));
                    soundManager.playLineClear();
                }
            }
        });
        
        // Keyboard controls
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_1:
                        soundManager.playPieceSelect();
                        break;
                    case KeyEvent.VK_2:
                        soundManager.playInvalidPlacement();
                        break;
                    case KeyEvent.VK_3:
                        soundManager.playGameOver();
                        break;
                    case KeyEvent.VK_L:
                        // Add line clear effects
                        activeEffects.add(new LineClearEffect(100, 200, 600, 40));
                        activeEffects.add(new LineClearEffect(200, 100, 40, 400));
                        soundManager.playLineClear();
                        break;
                    case KeyEvent.VK_M:
                        soundManager.toggleMute();
                        repaint();
                        break;
                }
            }
        });
        
        setFocusable(true);
        
        // Animation timer
        Timer timer = new Timer(16, e -> {
            updateEffects();
            repaint();
        });
        timer.start();
    }
    
    private void updateEffects() {
        activeEffects.removeIf(effect -> {
            effect.update();
            return effect.isFinished();
        });
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw all effects
        for (Effect effect : activeEffects) {
            effect.draw(g2d);
        }
        
        // Draw instructions
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.PLAIN, 14));
        g2d.drawString("Saim's Effects & Sound Test", 20, 30);
        g2d.drawString("Left Click: Placement Pop Effect", 20, 55);
        g2d.drawString("Right Click: Score Popup Effect", 20, 75);
        g2d.drawString("L Key: Line Clear Effects", 20, 95);
        g2d.drawString("1 Key: Select Sound", 20, 115);
        g2d.drawString("2 Key: Invalid Sound", 20, 135);
        g2d.drawString("3 Key: Game Over Sound", 20, 155);
        g2d.drawString("M Key: Toggle Mute", 20, 175);
        g2d.drawString("Muted: " + soundManager.isMuted(), 20, 195);
        g2d.drawString("Active Effects: " + activeEffects.size(), 20, 215);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Effects & Sound Test - Saim Arif Khan");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new TestEffects());
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
