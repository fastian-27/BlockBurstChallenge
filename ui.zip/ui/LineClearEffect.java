package blocked.ui;

import java.awt.*;

/**
 * Visual effect for clearing rows and columns.
 * Creates a flash animation that fades out over time.
 * 
 * @author Saim Arif Khan
 */
public class LineClearEffect extends Effect {
    
    private int width, height;
    private Color flashColor;
    
    /**
     * Creates a line clear effect for a horizontal row.
     * 
     * @param x Left edge X coordinate
     * @param y Top edge Y coordinate
     * @param width Width of the row
     * @param height Height of cells
     * @throws IllegalArgumentException if width or height is non-positive
     */
    public LineClearEffect(int x, int y, int width, int height) {
        super(x, y, 400);  // 400ms duration
        
        if (width <= 0) {
            throw new IllegalArgumentException("Width must be positive, got: " + width);
        }
        if (height <= 0) {
            throw new IllegalArgumentException("Height must be positive, got: " + height);
        }
        
        this.width = width;
        this.height = height;
        this.flashColor = new Color(255, 255, 100);  // Bright yellow flash
    }
    
    @Override
    public void draw(Graphics2D g2d) {
        if (g2d == null) {
            System.err.println("Error: Graphics2D context is null");
            return;
        }
        
        try {
            float progress = getProgress();
        
            // Flash bright at start, fade to transparent
            float alpha = 1.0f - progress;
            
            // Pulsing effect: flash twice
            if (progress < 0.25f) {
                alpha = progress * 4.0f;  // Fade in quickly
            } else if (progress < 0.5f) {
                alpha = 1.0f - (progress - 0.25f) * 4.0f;  // Fade out
            } else if (progress < 0.75f) {
                alpha = (progress - 0.5f) * 4.0f;  // Fade in again
            } else {
                alpha = 1.0f - (progress - 0.75f) * 4.0f;  // Final fade out
            }
            
            alpha = Math.max(0, Math.min(1, alpha));
            
            Color effectColor = new Color(
                flashColor.getRed(),
                flashColor.getGreen(),
                flashColor.getBlue(),
                (int) (alpha * 200)  // Max alpha of 200 to keep it semi-transparent
            );
            
            g2d.setColor(effectColor);
            g2d.fillRect(x, y, width, height);
            
            // Draw a bright border
            Color borderColor = new Color(
                255, 255, 255,
                (int) (alpha * 255)
            );
            g2d.setColor(borderColor);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawRect(x, y, width, height);
            
        } catch (Exception e) {
            System.err.println("Error drawing LineClearEffect: " + e.getMessage());
        }
    }
}
