package blocked.ui;

import java.awt.Graphics2D;

public abstract class Effect {
    
    protected int x, y;              
    protected long startTime;        
    protected int duration;          
    protected boolean finished;      
    
    /**
     * Creates a new effect at the given position.
     * 
     * @param x X coordinate
     * @param y Y coordinate
     * @param duration Duration in milliseconds
     * @throws IllegalArgumentException if duration is non-positive
     */
    public Effect(int x, int y, int duration) {
        if (duration <= 0) {
            throw new IllegalArgumentException("Effect duration must be positive, got: " + duration);
        }
        
        this.x = x;
        this.y = y;
        this.duration = duration;
        this.startTime = System.currentTimeMillis();
        this.finished = false;
    }
    
    /**
     * Updates the effect state based on elapsed time.
     * Should be called every frame.
     */
    public void update() {
        try {
            long currentTime = System.currentTimeMillis();
            long elapsed = currentTime - startTime;
            
            if (elapsed >= duration) {
                finished = true;
            }
        } catch (Exception e) {
            System.err.println("Error updating effect: " + e.getMessage());
            // Mark as finished on error to prevent infinite loop
            finished = true;
        }
    }
    
    public abstract void draw(Graphics2D g2d);
   
    public boolean isFinished() {
        return finished;
    }
    
    /**
     * Gets the progress of the effect from 0.0 to 1.0.
     * 
     * @return Progress value between 0.0 (just started) and 1.0 (finished)
     */
    protected float getProgress() {
        try {
            long currentTime = System.currentTimeMillis();
            long elapsed = currentTime - startTime;
            
            if (elapsed < 0) {
                // Clock went backwards, reset to start
                startTime = currentTime;
                return 0.0f;
            }
            
            if (duration <= 0) {
                return 1.0f;
            }
            
            return Math.min(1.0f, (float) elapsed / duration);
            
        } catch (Exception e) 
        { 
            System.err.println("Error calculating effect progress: " + e.getMessage());
            return 1.0f;  
        }
    }
}
