package blocked.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public class Renderer {

    private static final int BLOCK_SIZE = 50;

    private final Graphics2D graphics;

    public Renderer(Graphics2D graphics) {
        this.graphics = graphics;
    }

    public void drawBackground() {
        Color previousColor = graphics.getColor();
        graphics.setColor(Color.BLACK);
        graphics.fillRect(0, 0, graphics.getClipBounds().width, graphics.getClipBounds().height);
        graphics.setColor(previousColor);
    }

    public void drawBlock(int x, int y, Color color) {
        Color previousColor = graphics.getColor();
        graphics.setColor(color);
        graphics.fillRect(x, y, BLOCK_SIZE, BLOCK_SIZE);
        graphics.setColor(previousColor);
    }

    public void drawText(String text, int x, int y) {
        Color previousColor = graphics.getColor();
        Font previousFont = graphics.getFont();
        graphics.setColor(Color.WHITE);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        graphics.drawString(text, x, y);
        graphics.setColor(previousColor);
        graphics.setFont(previousFont);
    }
}
