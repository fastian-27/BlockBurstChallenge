package blocked.ui;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class SoundManager {
    
    private static SoundManager instance;
    
    private boolean muted = false;
    private Map<String, Clip> soundCache = new HashMap<>();
    
    // Sound effect file paths
    private static final String SOUND_DIR = "resources/sounds/";
    private static final String SELECT_SOUND = "select.wav";
    private static final String PLACE_SOUND = "place.wav";
    private static final String CLEAR_SOUND = "clear.wav";
    private static final String INVALID_SOUND = "invalid.wav";
    private static final String GAMEOVER_SOUND = "gameover.wav";
    
    /**
     * Private constructor for singleton pattern.
     */
    private SoundManager() {
        loadSounds();
    }
    
    /**
     * Gets the singleton instance of SoundManager.
     * 
     * @return The SoundManager instance
     */
    public static synchronized SoundManager getInstance() {
        if (instance == null) {
            instance = new SoundManager();
        }
        return instance;
    }
    
    /**
     * Loads all sound effects into memory.
     * Handles missing files gracefully by logging warnings.
     */
    private void loadSounds() {
        loadSound("select", SELECT_SOUND);
        loadSound("place", PLACE_SOUND);
        loadSound("clear", CLEAR_SOUND);
        loadSound("invalid", INVALID_SOUND);
        loadSound("gameover", GAMEOVER_SOUND);
    }
    
    /**
     * Loads a single sound file into the cache.
     * 
     * @param key The cache key for this sound
     * @param filename The filename in the sounds directory
     */
    private void loadSound(String key, String filename) {
        // Input validation
        if (key == null || key.trim().isEmpty()) {
            System.err.println("Error: Invalid sound key (null or empty)");
            return;
        }
        
        if (filename == null || filename.trim().isEmpty()) {
            System.err.println("Error: Invalid filename (null or empty)");
            return;
        }
        
        AudioInputStream audioStream = null;
        Clip clip = null;
        
        try {
            File soundFile = new File(SOUND_DIR + filename);
            
            if (!soundFile.exists()) {
                System.err.println("Warning: Sound file not found: " + soundFile.getAbsolutePath());
                System.err.println("Game will continue without this sound effect.");
                return;
            }
            
            if (!soundFile.canRead()) {
                System.err.println("Error: Cannot read sound file: " + soundFile.getAbsolutePath());
                System.err.println("Check file permissions.");
                return;
            }
            
            audioStream = AudioSystem.getAudioInputStream(soundFile);
            clip = AudioSystem.getClip();
            clip.open(audioStream);
            soundCache.put(key, clip);
            
            System.out.println("Loaded sound: " + filename);
            
        } catch (UnsupportedAudioFileException e) {
            System.err.println("Error: Unsupported audio format for " + filename);
            System.err.println("Please use WAV format. Details: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Error: Could not read sound file " + filename);
            System.err.println("Details: " + e.getMessage());
        } catch (LineUnavailableException e) {
            System.err.println("Error: Audio line unavailable for " + filename);
            System.err.println("Check if audio device is available. Details: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("Error: Invalid audio format for " + filename);
            System.err.println("Details: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error loading sound " + filename);
            System.err.println("Details: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Close audio stream to free resources
            if (audioStream != null) {
                try {
                    audioStream.close();
                } catch (IOException e) {
                    System.err.println("Warning: Could not close audio stream for " + filename);
                }
            }
        }
    }
    
    /**
     * Plays a sound effect by its key.
     * Does nothing if muted or if the sound failed to load.
     * 
     * @param key The sound cache key
     */
    private void playSound(String key) {
        // Input validation
        if (key == null || key.trim().isEmpty()) {
            System.err.println("Error: Invalid sound key (null or empty)");
            return;
        }
        
        if (muted) return;
        
        Clip clip = soundCache.get(key);
        if (clip == null) {
            // Sound not loaded, fail silently (already logged during load)
            return;
        }
        
        try {
            // Stop if already playing
            if (clip.isRunning()) {
                clip.stop();
            }
            
            // Reset to beginning and play
            clip.setFramePosition(0);
            clip.start();
            
        } catch (IllegalStateException e) {
            System.err.println("Error: Cannot play sound " + key + " - clip not properly initialized");
        } catch (Exception e) {
            System.err.println("Unexpected error playing sound " + key + ": " + e.getMessage());
        }
    }
    
    // ==================== PUBLIC SOUND METHODS ====================
    
    /**
     * Plays the piece selection sound.
     */
    public void playPieceSelect() {
        playSound("select");
    }
    
    /**
     * Plays the successful placement sound.
     */
    public void playPiecePlaced() {
        playSound("place");
    }
    
    /**
     * Plays the row/column clear sound.
     */
    public void playLineClear() {
        playSound("clear");
    }
    
    /**
     * Plays the invalid placement sound.
     */
    public void playInvalidPlacement() {
        playSound("invalid");
    }
    
    /**
     * Plays the game over sound.
     */
    public void playGameOver() {
        playSound("gameover");
    }
    
    // ==================== MUTE CONTROL ====================
    
    /**
     * Toggles mute on/off.
     */
    public void toggleMute() {
        muted = !muted;
        System.out.println("Sound " + (muted ? "muted" : "unmuted"));
    }
    
    /**
     * Sets the mute state.
     * 
     * @param muted true to mute, false to unmute
     */
    public void setMuted(boolean muted) {
        this.muted = muted;
    }
    
    /**
     * Checks if sound is currently muted.
     * 
     * @return true if muted, false otherwise
     */
    public boolean isMuted() {
        return muted;
    }
    
    // ==================== CLEANUP ====================
    
    /**
     * Closes all audio clips and releases resources.
     * Should be called when the application exits.
     */
    public void cleanup() {
        try {
            for (Clip clip : soundCache.values()) {
                if (clip != null) {
                    try {
                        if (clip.isRunning()) {
                            clip.stop();
                        }
                        clip.close();
                    } catch (Exception e) {
                        System.err.println("Warning: Error closing audio clip - " + e.getMessage());
                    }
                }
            }
            soundCache.clear();
            System.out.println("SoundManager cleanup complete");
        } catch (Exception e) {
            System.err.println("Error during SoundManager cleanup: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
