package blocked.ui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;
import javax.swing.Timer;

import blocked.model.Game;
import input.InputHandler;
import blocked.ui.screens.MenuScreen;
import blocked.ui.screens.PauseScreen;
import blocked.ui.screens.PlayScreen;
import blocked.ui.screens.Screen;

public class GamePanel extends JPanel {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int TIMER_DELAY_MS = 1000 / 60;

    private final Game game;
    private final InputHandler inputHandler;
    private Screen currentScreen;
    private final Timer gameTimer;
    private int draggedSlot = -1;
    private int dragX;
    private int dragY;
    private int selectedSlot = -1;
    private int previewRow;
    private int previewCol;
    private boolean paused;

    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(java.awt.Color.BLACK);
        setFocusable(true);
        game = new Game();
        inputHandler = new InputHandler(game, this);
        currentScreen = new MenuScreen();
        gameTimer = new Timer(TIMER_DELAY_MS, event -> {
            update();
            repaint();
        });

        addMouseListener(inputHandler);
        addMouseMotionListener(inputHandler);
        addKeyListener(inputHandler);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent event) {
                switch (event.getKeyCode()) {
                    case KeyEvent.VK_F1:
                        setCurrentScreen(new MenuScreen());
                        break;
                    case KeyEvent.VK_F2:
                        setCurrentScreen(new PlayScreen());
                        break;
                    case KeyEvent.VK_F3:
                        setCurrentScreen(new PauseScreen());
                        break;
                    default:
                        break;
                }
            }
        });
    }

    @Override
    public void addNotify() {
        super.addNotify();
        requestFocusInWindow();
        gameTimer.start();
    }

    @Override
    public void removeNotify() {
        gameTimer.stop();
        super.removeNotify();
    }

    private void toggleScreen() {
        if (currentScreen instanceof MenuScreen) {
            setCurrentScreen(new PlayScreen());
        } else {
            setCurrentScreen(new MenuScreen());
        }
    }

    public void update() {
        currentScreen.update();
    }

    private void setCurrentScreen(Screen screen) {
        currentScreen = screen;
        repaint();
    }

    public void handleMenuClick(int x, int y) {
        if (currentScreen instanceof MenuScreen) {
            toggleScreen();
        }
    }

    public void handleMenuKey() {
        if (currentScreen instanceof MenuScreen) {
            toggleScreen();
        }
    }

    public void setDragState(int slot, int x, int y) {
        draggedSlot = slot;
        dragX = x;
        dragY = y;
    }

    public void clearDragState() {
        draggedSlot = -1;
    }

    public void setKeyboardState(int slot, int row, int col) {
        selectedSlot = slot;
        previewRow = row;
        previewCol = col;
    }

    public void clearKeyboardState() {
        selectedSlot = -1;
    }

    public void setMousePosition(int x, int y) {
        dragX = x;
        dragY = y;
    }

    public void placePiece(int slot, int row, int col) {
        if (game.placePiece(slot, row, col)) {
            SoundManager.getInstance().playPiecePlaced();
        }
    }

    public void togglePause() {
        paused = !paused;
        if (paused) {
            setCurrentScreen(new PauseScreen());
            gameTimer.stop();
        } else {
            setCurrentScreen(new PlayScreen());
            gameTimer.start();
        }
    }

    public void restart() {
        game.reset();
        setCurrentScreen(new PlayScreen());
        draggedSlot = -1;
        selectedSlot = -1;
        paused = false;
        gameTimer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Renderer renderer = new Renderer((java.awt.Graphics2D) g);
        renderer.drawBackground();
        currentScreen.draw(renderer);
    }
}
