package blocked.ui;

import java.awt.*;

/**
 * Visual effect that shows when a piece is successfully placed.
 * Creates an expanding circle that fades out.
 * 
 * @author Saim Arif Khan
 */
public class PlacementPopEffect extends Effect {
    
    private int maxRadius;
    private Color popColor;
    
    /**
     * Creates a placement pop effect centered at the given position.
     * 
     * @param centerX Center X coordinate
     * @param centerY Center Y coordinate
     * @param maxRadius Maximum radius of the expanding circle
     * @throws IllegalArgumentException if maxRadius is non-positive
     */
    public PlacementPopEffect(int centerX, int centerY, int maxRadius) {
        super(centerX, centerY, 500);  // 500ms duration
        
        if (maxRadius <= 0) {
            throw new IllegalArgumentException("Max radius must be positive, got: " + maxRadius);
        }
        
        this.maxRadius = maxRadius;
        this.popColor = new Color(100, 200, 255);  // Light blue
    }
    
    @Override
    public void draw(Graphics2D g2d) {
        if (g2d == null) {
            System.err.println("Error: Graphics2D context is null");
            return;
        }
        
        try {
            float progress = getProgress();
        
            // Expand quickly, then fade out
            float scale = progress;
            float alpha = 1.0f - progress;
            
            int currentRadius = (int) (maxRadius * scale);
            
            Color effectColor = new Color(
                popColor.getRed(),
                popColor.getGreen(),
                popColor.getBlue(),
                (int) (alpha * 150)
            );
            
            // Draw expanding circle
            g2d.setColor(effectColor);
            g2d.setStroke(new BasicStroke(3));
            g2d.drawOval(
                x - currentRadius,
                y - currentRadius,
                currentRadius * 2,
                currentRadius * 2
            );
            
            // Draw a second, slightly larger circle for extra effect
            if (progress < 0.7f) {
                int outerRadius = (int) (currentRadius * 1.2f);
                Color outerColor = new Color(
                    popColor.getRed(),
                    popColor.getGreen(),
                    popColor.getBlue(),
                    (int) (alpha * 80)
                );
                g2d.setColor(outerColor);
                g2d.drawOval(
                    x - outerRadius,
                    y - outerRadius,
                    outerRadius * 2,
                    outerRadius * 2
                );
            }
            
        } catch (Exception e) {
            System.err.println("Error drawing PlacementPopEffect: " + e.getMessage());
        }
    }
}
